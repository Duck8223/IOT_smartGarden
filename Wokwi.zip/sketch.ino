#include <DHTesp.h>
#include <LiquidCrystal_I2C.h>
#include <Stepper.h>
#include <ESP32Servo.h>
#include <WiFi.h>
#include "PubSubClient.h"
//mqtt declare
const char * MQTTServer = "broker.emqx.io";
const char * MQTT_action = "testtopic/control_sg";
const char * MQTT_data = "testtopic/data_sg";
const char * MQTT_lenh = "testtopic/lenh";
const char * MQTT_chtemp = "testtopic/tpc_temp";
const char * MQTT_chmois = "testtopic/tpc_mois";
const char * MQTT_chrain = "testtopic/tpc_rain";
const char * MQTT_chlight = "testtopic/tpc_light";
const char * MQTT_nkc = "testtopic/nkc";
const char * MQTT_nkc_res = "testtopic/nkc_res";

WiFiClient espClient;
PubSubClient client(espClient);
 // Tạo ID ngẫu nhiên tại: https://www.guidgen.com/
const char * MQTT_ID = "cfd14e88-d54f-48a4-9e4f-aca1c87308ae";
int Port = 1883;

void WIFIConnect() {
  Serial.println("Connecting to SSID: Wokwi-GUEST");
  WiFi.begin("Wokwi-GUEST", "");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.print("WiFi connected");
  Serial.print(", IP address: ");
  Serial.println(WiFi.localIP());
}

void MQTT_Reconnect() {
  while (!client.connected()) {
    if (client.connect(MQTT_ID)) {
      client.subscribe(MQTT_lenh);
      client.subscribe(MQTT_chtemp);
      client.subscribe(MQTT_chmois);
      client.subscribe(MQTT_chrain);
      client.subscribe(MQTT_chlight);
      client.subscribe(MQTT_nkc);
      client.subscribe(MQTT_nkc_res);
      Serial.print("MQTT subscribe Topic: ");
      Serial.print(MQTT_lenh);
      Serial.println(" connected");

      Serial.print("MQTT publish Topic: ");
      Serial.print(MQTT_action);
      Serial.println(" connected");
      
      Serial.print("MQTT publish Topic: ");
      Serial.print(MQTT_data);
      Serial.println(" connected");
      Serial.println("");
      
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      delay(5000);
    }
  }
}

int per_moisture=0;
int per_light=0;
int per_rain=0;
float temperature=0;

bool web_battuw=false;
bool web_tattuw=false;

bool web_batsuw=false;
bool web_tatsuw=false;

bool web_batsuoi=false;
bool web_tatsuoi=false;

bool web_dongrain=false;
bool web_morain=false;

bool web_donglight=false;
bool web_molight=false;

int maxtemp=35;
int mintemp=28;

int maxmois=60;
int minmois=20;

int maxrain=80;

int maxlight=70;

bool k_c=false;



void callback(char* topic, byte* message, unsigned int length) {
  Serial.print("Message arrived on topic: ");
  Serial.println(topic);
  Serial.print("Message: ");
  String stMessage;

  for (int i = 0; i < length; i++) {
    Serial.print((char)message[i]);
    stMessage += (char)message[i];
  }
  Serial.println("");
  if(strcmp(topic, MQTT_lenh) == 0){
    if(stMessage=="1"){
      if( per_moisture>=maxmois){
        client.publish(MQTT_action, "overtuw");
      }else{
        //tuoi_nuoc.step(20);
        web_battuw=true;
        web_tattuw=false;
        String message_hd="battuoi";
        client.publish(MQTT_action, message_hd.c_str());
      }
      
    }else if(stMessage=="-1"){
      if(per_moisture<=minmois){
        client.publish(MQTT_action, "overtuw");
      }else{
        //tuoi_nuoc.step(0);
        web_tattuw=true;
        web_battuw=false;
        String message_hd="tattuoi";
        client.publish(MQTT_action, message_hd.c_str());
      }
      
    }else if(stMessage=="2"){
      if(temperature<=mintemp){
        client.publish(MQTT_action, "oversuw");
      }else{
        //suong.step(20);
        web_batsuw=true;
        web_tatsuw=false;
        String message_hd="batsuong";
        client.publish(MQTT_action, message_hd.c_str());
      }
      
    }else if(stMessage=="-2"){
      if(temperature>=maxtemp){
        client.publish(MQTT_action, "oversuw");
      }else{
        //suong.step(0);
        web_tatsuw=true;
        web_batsuw=false;
        String message_hd="tatsuong";
        client.publish(MQTT_action, message_hd.c_str());
      }
      
    }else if(stMessage=="3"){
      if(temperature>=maxtemp){
        client.publish(MQTT_action, "oversuoi");
      }else{
        //digitalWrite(den_suoi, HIGH);
        web_batsuoi=true;
        web_tatsuoi=false;
        String message_hd="batsuoi";
        client.publish(MQTT_action, message_hd.c_str());
      }
      
    }else if(stMessage=="-3"){
      if(temperature<=mintemp){
        client.publish(MQTT_action, "oversuoi");
      }else{
        //digitalWrite(den_suoi, LOW);
        web_tatsuoi=true;
        web_batsuoi=false;
        String message_hd="tatsuoi";
        client.publish(MQTT_action, message_hd.c_str());
      }
      
    }else if(stMessage=="4"){
      //man_chemua1.write(180);
      web_dongrain=true;
      web_morain=false;
      String message_hd="dongmua";
      client.publish(MQTT_action, message_hd.c_str());
    
      
    }else if(stMessage=="-4"){
      if(per_rain > maxrain){
        client.publish(MQTT_action, "overrain");
      }else{
        //man_chemua1.write(0);
        web_morain=true;
        web_dongrain=false;
        String message_hd="momua";
        client.publish(MQTT_action, message_hd.c_str());
      }
      
    }else if(stMessage=="5"){
      //man_che.write(180);
      web_donglight=true; 
      web_molight=false;
      String message_hd="dongnang";
      client.publish(MQTT_action, message_hd.c_str());
      
    }else if(stMessage=="-5"){
      if(per_light >maxlight){
        client.publish(MQTT_action, "overlight");
      }else{
        //man_che.write(0);
        web_molight=true;
        web_donglight=false;
        String message_hd="monang";
        client.publish(MQTT_action, message_hd.c_str());
      }  
    }
  }

  if(strcmp(topic, MQTT_chtemp) == 0){   
    int commaIndex = stMessage.indexOf('|');
    if (commaIndex != -1) {
      String firstPart = stMessage.substring(0, commaIndex);
      String secondPart = stMessage.substring(commaIndex + 1);
      maxtemp = firstPart.toInt();
      mintemp = secondPart.toInt();
      }

  }
  if(strcmp(topic, MQTT_chmois) == 0){
    int commaIndex = stMessage.indexOf('|');
    if (commaIndex != -1) {
      String firstPart = stMessage.substring(0, commaIndex);
      String secondPart = stMessage.substring(commaIndex + 1);
      maxmois = firstPart.toInt();
      minmois = secondPart.toInt();
    }
  }if(strcmp(topic, MQTT_chrain) == 0){
    maxrain= stMessage.toInt();
  }
  if(strcmp(topic, MQTT_chlight) == 0){
    maxlight= stMessage.toInt();
  }
  if(strcmp(topic, MQTT_nkc) == 0){
    if(stMessage=="1"){
      k_c=false;
    }else{
      k_c=true;

    }
  }
  

}


bool isAwningOpen = false; // Biến theo dõi trạng thái màn che
bool israinOpen = false;
const float GAMMA = 0.7;
const float RL10 = 50;
//
#define soil_moisture 35
// #define light 32
#define light 32

#define rain 33
#define servoPin 15
#define servoPinRain1 26
#define servoPinRain2 27


#define den_suoi 23

//stepper declare
Stepper tuoi_nuoc(100, 17,5, 18, 19);
Stepper suong(100, 2,0, 4, 16);

//

//servo declare
Servo man_che;
Servo man_chemua1;
Servo man_chemua2;


//

// DHT declare
const int DHT_22= 25;
DHTesp dhtSensor;
//

//lcd declare
LiquidCrystal_I2C lcd(0x27, 20, 4);
//

void setup() {
  Serial.begin(115200);
  Serial.println("Hello, ESP32!");
  pinMode(den_suoi, OUTPUT);
  //wifi&mqtt
  WIFIConnect();
  client.setServer(MQTTServer, Port);
  client.setCallback(callback);
  //

  // DHT setup
  dhtSensor.setup(DHT_22, DHTesp::DHT22);
  //

  // lcd setup
  lcd.init(); 
  lcd.backlight();
  //

  //stepper setup
  tuoi_nuoc.setSpeed(10);
  suong.setSpeed(10);
  //

  //servo setup
  man_che.attach(servoPin, 500, 2400);
  man_chemua1.attach(servoPinRain1, 500, 2400);
  man_chemua2.attach(servoPinRain2, 500, 2400);
  //

  // soil_moisture
  pinMode(soil_moisture, INPUT);
  //

  // light
  pinMode(light, INPUT);
  //

  // rain
  pinMode(rain, INPUT);
  //
}

//một số biến kiểm tra
bool cn_tn=false;
bool cn_suw=false;
bool cn_ds=false;
String nkc_res="0";

void loop() {
  delay(10);
  if (!client.connected()) {
    MQTT_Reconnect();
  }
  client.loop();

  if(k_c && nkc_res=="0"){
    nkc_res="1";
    client.publish(MQTT_nkc_res,nkc_res.c_str());
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Emergency stop");
    man_chemua1.write(180);
    tuoi_nuoc.step(0);
    suong.step(0);
    digitalWrite(den_suoi, LOW);
    man_chemua1.write(0);

  }else if(k_c==false && nkc_res=="1"){
    nkc_res="0";
    client.publish(MQTT_nkc_res,nkc_res.c_str());
  }else if(k_c==false){ 
    lcd.clear();

    //tt_web
    if(web_battuw){
      tuoi_nuoc.step(20);
      
    }else if(web_tattuw){
      tuoi_nuoc.step(0);
      
    } 

    if(web_batsuw){
      suong.step(20);
      
    }else if(web_tatsuw){
      suong.step(0);
      
    }

    if(web_batsuoi){
      digitalWrite(den_suoi, HIGH);
      
    }else if(web_tatsuoi){
      digitalWrite(den_suoi, LOW);
      
    }

    if(web_dongrain){
      man_chemua1.write(180);
      
    }else if(web_morain){
      man_chemua1.write(0);
      
    }

    if(web_donglight){
      man_che.attach(servoPin);
      man_che.write(180);
      
    }else if(web_molight){
      man_che.attach(servoPin);
      man_che.write(0);
      
    }

    //

    //data soil_moisture
    int moisture_value= analogRead(soil_moisture);
    per_moisture=map(moisture_value, 0, 4095, 0, 100);
    //

    //data light
    int light_value= analogRead(light);
    per_light=map(light_value, 4095, 0, 0, 100);
    //

    //data rain
    int rain_value= analogRead(rain);
    per_rain=map(rain_value, 0, 4095, 0, 100);
    //

    // DHT get data 
    
    temperature = dhtSensor.getTemperature();
    Serial.println("Temp: " + String(temperature) + "°C");
    Serial.println("Mois: " + String(temperature) + "°C");
    Serial.println("Rain: " + String(temperature) + "°C");

    
    //
    
    // lcd show data
    lcd.setCursor(0, 0);
    lcd.print("Temp:" + String(temperature) + "C ");
    lcd.setCursor(0, 1);
    lcd.print("mois: " + String(per_moisture) + "%");
    lcd.setCursor(0, 3);
    lcd.print("light: " + String(per_light) );
    lcd.setCursor(0, 2);
    lcd.print("rain: " + String(per_rain) + "%");
    //

    //cn_tuoi_nuoc
    if (per_moisture<= minmois ){
      cn_tn=true;
      tuoi_nuoc.step(20);
    }else if(per_moisture>= maxmois ){ 
      cn_tn=false;
      tuoi_nuoc.step(0);
    }

    if(cn_tn || web_battuw){
      String message_hd="battuoi";
      client.publish(MQTT_action, message_hd.c_str());
    }else if(cn_tn==false || web_tattuw){
      String message_hd="tattuoi";
      client.publish(MQTT_action, message_hd.c_str());
    }
    //

    //cn_suong_&_den_suoi
    if(temperature>= maxtemp ){
      cn_suw=true;
      suong.step(20);
      digitalWrite(den_suoi, LOW);
    }else if(temperature<= mintemp ){
      suong.step(0);
      cn_suw=false;
    }

    if(cn_suw || web_batsuw ){
      String message_suw="batsuong";
      client.publish(MQTT_action, message_suw.c_str());
    }else if(cn_suw==false || web_tatsuw){
      String message_hd="tatsuong";
      client.publish(MQTT_action, message_hd.c_str());
    }

    if(temperature<= mintemp ){   
      cn_ds=true;
      digitalWrite(den_suoi, HIGH);
      suong.step(0);
    }else if (temperature>= maxtemp ){    
      cn_ds=false;
      digitalWrite(den_suoi, LOW);
    }

    if(cn_ds || web_batsuoi){
      String message_ds="batsuoi";
      client.publish(MQTT_action, message_ds.c_str());
    }else if(cn_ds==false || web_tatsuoi){
      String message_hd="tatsuoi";
      client.publish(MQTT_action, message_hd.c_str());
    }

    //Chuc nang dong mang che neu gia tri sang duoi 100
    Serial.print("Giá trị ánh sáng: ");
    Serial.println(per_light);

  if (per_light > maxlight) { // Nếu giá trị ánh sáng nhỏ hơn 500, bật servo mở màn che
      
      if (!isAwningOpen) { // Kiểm tra xem màn che có đang mở hay không
        man_che.attach(servoPin); // Kết nối servo     
        man_che.write(180);
        delay(15);     
        // Giữ servo ở vị trí mở trong 1 giây
        isAwningOpen = true; // Cập nhật trạng thái màn che
      }
    } else { 
      if (isAwningOpen) { // Kiểm tra xem màn che có đang đóng hay không     
        man_che.write(0);
        delay(15);     
        man_che.detach(); // Ngắt kết nối servo
        isAwningOpen = false; // Cập nhật trạng thái màn che
      }
    }

    //cập nhật trạng thái màn che
    if(isAwningOpen || web_donglight){
      String message_hd="dongnang";
      client.publish(MQTT_action, message_hd.c_str());
    }else if(isAwningOpen==false || web_molight){
      String message_hd="monang";
      client.publish(MQTT_action, message_hd.c_str());
    }


    //Chuc nang dong mang neu mua lơn mua nhỏ
    if (per_rain < maxrain ) {
      if(web_dongrain){
        israinOpen=false;
      }else{
        man_chemua1.write(0); // Góc đóng màn che 1
        // Màn che 2 đóng hoàn toàn
        israinOpen=true;
      }
      
    }  else if (per_rain >= maxrain ) {
      // Mưa to, kéo cả 2 màn che
      man_chemua1.write(180); // Góc đóng màn che 1
      // Góc đóng màn che 2
      israinOpen=false;
      delay(1000);       // Delay cho việc mở cả 2 màn che
    }

    if(israinOpen || web_morain){
      String message_hd="momua";
      client.publish(MQTT_action, message_hd.c_str());
    }else if(israinOpen==false || web_dongrain){
      String message_hd="dongmua";
      client.publish(MQTT_action, message_hd.c_str());
    }

    delay(300); // Chờ 3 giây cho lần lặp tiếp theo



    // Tạo chuỗi tin nhắn
    String message_dl = String(temperature)+ "|" + String(per_moisture)+ "|" + String(per_rain) + "|" + String(per_light);

    // Gửi tin nhắn
    client.publish(MQTT_data, message_dl.c_str());

    delay(3000); // this speeds up the simulation
  }

  
}
